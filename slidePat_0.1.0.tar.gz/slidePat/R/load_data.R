#'Load example data
#
#'@export

load(file.path("inst", "extdata", "SLiPat_data.RData"))
