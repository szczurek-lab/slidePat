# slidePat

slidePat includes Synthetic Lethality tests: 

* exprSL
* SoF 
* SurvLRT
* iSurvLRT 

 and is part of "SLIDE-VIP: a comprehensive, cell line- and patient-based framework for synthetic lethality prediction in DNA damage repair, chromatin remodeling and cell cycle""
